/** Messages for Malay (Bahasa Melayu)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Anakmalaysia
 */
var I18n={on_leave_page:"Anda mungkin kehilangan pengubahan anda",loading:"Sedang dimuatkan..."};