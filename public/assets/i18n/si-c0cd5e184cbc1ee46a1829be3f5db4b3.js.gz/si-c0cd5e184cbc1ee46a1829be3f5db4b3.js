/** Messages for Sinhala (සිංහල)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Singhalawap
 */
var I18n={on_leave_page:"ඔබගේ වෙනස්කිරීම් අහිමිවනු ඇත"};