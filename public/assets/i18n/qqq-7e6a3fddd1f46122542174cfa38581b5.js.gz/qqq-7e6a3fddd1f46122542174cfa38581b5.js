/** Messages for Message documentation (Message documentation)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - EugeneZelenko
 */
var I18n={loading:"{{Identical|Loading}}"};