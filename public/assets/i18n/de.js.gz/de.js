/** Messages for German (Deutsch)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Kghbln
 *  - Siebrand
 */
var I18n={on_leave_page:"Deine Änderungen könnten verloren gehen",loading:"Lade …"};