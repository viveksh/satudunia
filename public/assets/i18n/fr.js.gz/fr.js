/** Messages for French (français)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Jean-Frédéric
 *  - Siebrand
 */
var I18n={on_leave_page:"Vous pourriez perdre des modifications faits à cette page",loading:"Chargement…"};