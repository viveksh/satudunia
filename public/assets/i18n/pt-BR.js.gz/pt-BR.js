/** Messages for Brazilian Portuguese (português do Brasil)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Giro720
 */
var I18n={on_leave_page:"Você poderá perder suas alterações"};