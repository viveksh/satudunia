/** Messages for Afrikaans (Afrikaans)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Naudefj
 */
var I18n={on_leave_page:"U kan u veranderinge verloor"};