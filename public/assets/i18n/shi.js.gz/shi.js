/** Messages for Tachelhit (Tašlḥiyt/ⵜⴰⵛⵍⵃⵉⵜ)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Dalinanir
 */
var I18n={on_leave_page:"Radak jlun imbdln lli tskrt ɣ tasna yad"};