/** Messages for English (English)
 *  Exported from translatewiki.net
 *

 */
var I18n={on_leave_page:"You may lose your changes",loading:"Loading..."};