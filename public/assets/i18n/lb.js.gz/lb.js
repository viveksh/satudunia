/** Messages for Luxembourgish (Lëtzebuergesch)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Robby
 */
var I18n={on_leave_page:"Et ka sinn datt Är Ännerunge verluer ginn"};