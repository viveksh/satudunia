/** Messages for Serbian (Cyrillic script) (српски (ћирилица)‎)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Rancher
 */
var I18n={on_leave_page:"Изгубићете измене које сте направили",loading:"Учитавам…"};