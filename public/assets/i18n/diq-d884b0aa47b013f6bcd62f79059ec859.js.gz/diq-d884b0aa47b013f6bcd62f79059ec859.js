/** Messages for Zazaki (Zazaki)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Erdemaslancan
 */
var I18n={loading:"Bar beno..."};