/** Messages for Ukrainian (українська)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Тест
 */
var I18n={on_leave_page:"Ви можете втратити ваші зміни"};