/** Messages for Dutch (Nederlands)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Siebrand
 */
var I18n={on_leave_page:"Uw wijzigingen kunnen verloren gaan.",loading:"Bezig met laden…"};