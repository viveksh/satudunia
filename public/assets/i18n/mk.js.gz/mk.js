/** Messages for Macedonian (македонски)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Bjankuloski06
 *  - Siebrand
 */
var I18n={on_leave_page:"Може да ви се изгубат промените",loading:"Вчитувам..."};