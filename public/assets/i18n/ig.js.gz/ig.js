/** Messages for Igbo (Igbo)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Ukabia
 */
var I18n={on_leave_page:"Ihe Í rürü nwèríkí fù éfù"};