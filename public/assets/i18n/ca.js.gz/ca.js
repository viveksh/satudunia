/** Messages for Catalan (català)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Gemmaa
 *  - Papapep
 */
var I18n={on_leave_page:"Podeu perdre els vostres canvis",loading:"Carregant..."};