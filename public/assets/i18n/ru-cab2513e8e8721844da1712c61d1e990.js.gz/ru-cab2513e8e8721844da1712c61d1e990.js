/** Messages for Russian (русский)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Adata80
 *  - Siebrand
 */
var I18n={on_leave_page:"Ваши изменения могут быть потеряны",loading:"Загрузка..."};