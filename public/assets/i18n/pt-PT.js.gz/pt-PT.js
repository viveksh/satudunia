/** Messages for Portuguese (português)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Hamilton Abreu
 */
var I18n={on_leave_page:"Poderá perder as suas alterações"};