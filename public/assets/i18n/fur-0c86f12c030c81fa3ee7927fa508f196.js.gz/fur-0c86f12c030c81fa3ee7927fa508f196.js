/** Messages for Friulian (furlan)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Klenje
 */
var I18n={on_leave_page:"Tu podaressis pierdi i tiei cambiaments"};