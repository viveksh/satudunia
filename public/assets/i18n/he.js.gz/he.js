/** Messages for Hebrew (עברית)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - YaronSh
 */
var I18n={on_leave_page:"השינויים שלך עלולים ללכת לאיבוד"};