/** Messages for Esperanto (Esperanto)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Darkweasel
 */
var I18n={on_leave_page:"Vi eble perdos viajn ŝanĝojn"};