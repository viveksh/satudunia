/** Messages for Italian (italiano)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Danmaz74
 *  - Giallu
 */
var I18n={on_leave_page:"Le modifiche potrebbero andare perse",loading:"Caricamento in corso…"};