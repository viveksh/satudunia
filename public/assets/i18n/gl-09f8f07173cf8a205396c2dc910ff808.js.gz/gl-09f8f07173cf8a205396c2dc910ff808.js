/** Messages for Galician (galego)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Siebrand
 *  - Toliño
 */
var I18n={on_leave_page:"Pode perder as súas modificacións",loading:"Cargando..."};