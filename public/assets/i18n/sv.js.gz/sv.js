/** Messages for Swedish (svenska)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Tobulos1
 */
var I18n={on_leave_page:"Du kan förlora dina ändringar"};