/** Messages for Hungarian (magyar)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Dani
 *  - Dj
 */
var I18n={on_leave_page:"Lehet, hogy elveszíted a változtatásaidat",loading:"Betöltés…"};