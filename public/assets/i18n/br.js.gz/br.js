/** Messages for Breton (brezhoneg)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Siebrand
 */
var I18n={on_leave_page:"Marteze emaoc'h o vont da goll kemmoù bet degaset d'ar bajenn-mañ"};