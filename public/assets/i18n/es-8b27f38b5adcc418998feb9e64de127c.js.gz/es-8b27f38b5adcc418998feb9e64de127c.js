/** Messages for Spanish (español)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Patcito
 */
var I18n={on_leave_page:"Podrías perder tus cambios",loading:"Cargando..."};