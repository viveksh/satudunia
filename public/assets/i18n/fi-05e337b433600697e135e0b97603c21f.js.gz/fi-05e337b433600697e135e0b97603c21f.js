/** Messages for Finnish (suomi)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Centerlink
 */
var I18n={on_leave_page:"Saatat menettää tekemäsi muutokset",loading:"Ladataan…"};