/** Messages for Simplified Chinese (中文（简体）‎)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Hydra
 *  - Hzy980512
 */
var I18n={on_leave_page:"您可能会丢失所做的更改",loading:"载入中..."};