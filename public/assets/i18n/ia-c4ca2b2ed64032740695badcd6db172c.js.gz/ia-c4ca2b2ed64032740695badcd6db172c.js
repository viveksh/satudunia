/** Messages for Interlingua (interlingua)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - McDutchie
 */
var I18n={on_leave_page:"Tu poterea perder tu modificationes",loading:"Cargamento in curso…"};