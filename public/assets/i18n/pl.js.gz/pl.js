/** Messages for Polish (polski)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Grzechooo
 *  - Siebrand
 */
var I18n={on_leave_page:"Możesz utracić wykonane zmiany",loading:"Ładowanie..."};