/** Messages for Telugu (తెలుగు)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Veeven
 */
var I18n={on_leave_page:"మీరు మీ మార్పులని కోల్పోవచ్చు"};