/** Messages for Persian (فارسی)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - MindHammerGames
 */
var I18n={on_leave_page:"ممکن است تغییراتی که انجام داده اید را از دست بدهید"};