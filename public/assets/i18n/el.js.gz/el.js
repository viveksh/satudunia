/** Messages for Greek (Ελληνικά)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Siebrand
 */
var I18n={on_leave_page:"Μπορεί να χάσετε τις αλλαγές σας"};