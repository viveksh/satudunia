/** Messages for Piedmontese (Piemontèis)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Dragonòt
 */
var I18n={on_leave_page:"It peule perde ij tò cambi"};