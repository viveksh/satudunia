/** Messages for Traditional Chinese (‪中文(繁體)‬)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Frankou
 */
var I18n={on_leave_page:"你可能會失去您的變更"};