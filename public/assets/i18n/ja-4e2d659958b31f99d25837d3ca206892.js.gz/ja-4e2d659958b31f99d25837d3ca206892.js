/** Messages for Japanese (日本語)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Shirayuki
 */
var I18n={on_leave_page:"変更内容を失う恐れがあります"};