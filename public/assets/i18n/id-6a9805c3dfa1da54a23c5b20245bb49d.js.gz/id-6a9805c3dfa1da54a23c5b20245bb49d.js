/** Messages for Indonesian (Bahasa Indonesia)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Farras
 */
var I18n={on_leave_page:"Perubahan yang Anda buat akan hilang"};