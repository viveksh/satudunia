/** Messages for Belarusian (Taraškievica orthography) (беларуская (тарашкевіца)‎)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Jim-by
 */
var I18n={on_leave_page:"Вашыя зьмены могуць быць страчаныя",loading:"Загрузка…"};