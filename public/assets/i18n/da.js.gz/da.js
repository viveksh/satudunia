/** Messages for Danish (dansk)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Emilkris33
 */
var I18n={on_leave_page:"Du kan miste dine ændringer"};