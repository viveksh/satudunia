/** Messages for Serbian (Latin script) (srpski (latinica)‎)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Rancher
 */
var I18n={on_leave_page:"Izgubićete izmene koje ste napravili",loading:"Učitavam…"};