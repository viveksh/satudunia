/** Messages for Norwegian Bokmål (norsk (bokmål)‎)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Siebrand
 */
var I18n={on_leave_page:"Du kan miste endringene dine"};