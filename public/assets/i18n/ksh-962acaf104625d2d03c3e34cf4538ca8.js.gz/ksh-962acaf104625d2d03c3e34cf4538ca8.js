/** Messages for Colognian (Ripoarisch)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Purodha
 */
var I18n={on_leave_page:"Ding Änderonge künnte verschött jonn",loading:"Aam Laade&nbsp;&hellip;"};