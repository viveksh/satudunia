/** Messages for Tagalog (Tagalog)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - AnakngAraw
 */
var I18n={on_leave_page:"Maaari mawala ang mga binago mo",loading:"Ikinakarga..."};