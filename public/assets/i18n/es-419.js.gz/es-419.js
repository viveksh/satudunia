/** Messages for Latin American Spanish (espanol de America Latina)
 *  Exported from translatewiki.net
 *
 * Translators:
 *  - Siebrand
 */
var I18n={on_leave_page:"Podrias perder tus cambios"};